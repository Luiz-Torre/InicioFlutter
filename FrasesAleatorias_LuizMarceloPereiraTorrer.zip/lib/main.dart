import 'package:flutter/material.dart';
import 'package:frasesaleatorias/pages/home.dart';
void main() {
  runApp(
    const MaterialApp(
          title: "Frases Aleatórias",
          home: Home()
    )
  );
  
}
